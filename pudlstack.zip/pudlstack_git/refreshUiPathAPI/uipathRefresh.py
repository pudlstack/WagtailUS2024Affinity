import requests
import json

with open('/var/www/acgCodeSave/refreshToken.txt') as f:
    refreshToken = f.read()

with open('/var/www/acgCodeSave/accessToken.txt') as f:
    accessToken = f.read()

url = "https://cloud.uipath.com/identity_/connect/token"

payload='grant_type=refresh_token&client_id=<your uipath app id here>&refresh_token=' + refreshToken.strip()
headers = {
  'Authorization': 'Bearer '+ accessToken.strip(), 
  'Content-Type': 'application/x-www-form-urlencoded'
}

response = requests.request("POST", url, headers=headers, data=payload)

print("Response is: "+response.text)

# some JSON:

# parse x:
y = json.loads(response.text)

# the result is a Python dictionary:
print('New Access Token:' + y["access_token"])
print('New Refresh Toen:' + y["refresh_token"])

f = open("/var/www/acgCodeSave/refreshToken.txt","w")
f.write(y["refresh_token"])

f = open("/var/www/acgCodeSave/accessToken.txt","w")
f.write(y["access_token"])

