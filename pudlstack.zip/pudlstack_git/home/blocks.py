from wagtail.blocks import (
        CharBlock,
        ChoiceBlock,
        RichTextBlock,
        BooleanBlock,
        StreamBlock,
        StructBlock,
        TextBlock,
)
from wagtail.images.blocks import ImageChooserBlock
from wagtailcharts.blocks import ChartBlock

COLORS = (
    ('#1f83b4', 'Blue'),
    ('#12a2a8', 'Eastern Blue'),
    ('#2ca030', 'Forest green'),
    ('#78a641', 'Sushi'),
    ('#bcbd22', 'Key Lime Pie'),
    ('#ffbf50', 'Texas rose'),
    ('#ffaa0e', 'Yellow sea'),
    ('#ff7f0e', 'Flamenco'),
    ('#d63a3a', 'Valencia'),
    ('#c7519c', 'Mulberry'),
    ('#ba43b4', 'Fuchsia Pink'),
    ('#8a60b0', 'Wisteria'),
    ('#6f63bb', 'Blue Violet'),
)

CHART_TYPES = (
    ('line', 'Line Chart'),
    ('bar', 'Vertical Bar Chart'),
    ('bar_horizontal', 'Horizontal Bar Chart'),
    ('area', 'Area Chart'),
    ('multi', 'Combo Line/Bar/Area Chart'),
    ('pie', 'Pie Chart'),
    ('doughnut', 'Doughnut Chart'),
    ('radar', 'Radar Chart'),
    ('polar', 'Polar Chart'),
    ('waterfall', 'Waterfall Chart')
)


class TitleAndTextBlock(StructBlock):
    """ Title and text and nothing else """

    title = CharBlock(required=True, help_text='Add your title')
    text = TextBlock(required=True, help_text='Add your text')

    class Meta:
            template = "blocks/title_and_text_block.html"
            icon = "edit"
            label = "Title & Text"

class ChartsBlock(StructBlock):
    """
    Custom `StructBlock` for charts
    """
    chart_block_custom = ChartBlock(label="My custom chart block", colors=COLORS, chart_types=CHART_TYPES)

    class Meta:
        icon = "chart-line"
        label = "Charts"

class ImageBlock(StructBlock):
    """
    Custom `StructBlock` for utilizing images with associated caption and
    attribution data
    """
    image = ImageChooserBlock(required=True)
    caption = CharBlock(required=False)
    attribution = CharBlock(required=False)

    class Meta:
        template = "blocks/image_block.html"
        icon = "image"
        label = "Images"

class UipathBlock(StructBlock):
    #api_url = models.URLField(verbose_name="API URL")
    #cached_data = models.JSONField(blank=True, null=True, verbose_name="Cached API Data")
    #last_updated = models.DateTimeField(blank=True, null=True, verbose_name="Last Updated")
    botTitle = CharBlock(required=True, help_text='Add your title')
    botDescription = RichTextBlock(blank=True)
    botInstagramHandle = CharBlock(required=True, help_text='Enter handle to chart')

    class Meta:
        template = "blocks/uipath_block.html"
        icon = "robot"
        label = "uipath"

    def get_dummy_string():
        return "Dummy Test String"

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)

       # Get Robot Chart Data
       # Priority 2: Fetch data from API using requests
        import requests
        import json
        url = "https://cloud.uipath.com/cognitivemetaphors/CognitiveMetaphors/dataservice_/api/EntityService/SocMedFollowing/query?expansionLevel=2"

        # Read latest access token. I have a cron job refreshing this every hour.
        with open('/var/www/acgCodeSave/accessToken.txt') as f:
            accessToken = f.read().strip()

        payload = json.dumps({
        "selectedFields": [
            "CreateTime",
            "Handle",
            "Followers"
        ],
        "filterGroup": {
            "logicalOperator": 0,
            "queryFilters": [
            {
                "fieldName": "Handle",
                "operator": "=",
                "value": "alyssaggarcia"
            }
            ],
            "filterGroups": [
            None
            ]
        },
        "start": 0,
        "limit": 10,
        "sortOptions": [
            {
            "fieldName": "CreateTime",
            "isDescending": True 
            }
        ]
        })
        headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accessToken + '',
        'Cookie': '__cf_bm=BFo1gKprW8S6Ekge181.zMSlY5l9uA7VoBhjSOGik74-1711785156-1.0.1.1-JHUtBt0q92jhgvjK11wCfyvlzU1cSQ3qYKqL3iQTrlMr0hVibAhOdc26h4.JwVujZYTdVjdYhjfx9t4SO_ZBJA; _cfuvid=eg5n0AYtAa9yjcA4Ri3X.loz0XXdwgxta.xEvLbQJJo-1711783844858-0.0.1.1-604800000'
        }

        response = requests.request("POST", url, headers=headers, data=payload)

        if response.status_code == 200:
            context['api_data'] = response.json()
        else:
            context['api_data'] = None  # Handle API errors gracefully (optional)

        # Get robot chart commentart
        import google.generativeai as genai

        # API Key
        genai.configure(api_key="<your google api key here>")
        prompt = "summarize the most significant changes of followers over createtime in this json " + str(response.json()) + ". Give specific observations in a 4 sentence paragraph."

        model_name = genai.GenerativeModel('gemini-pro')
                                                                                                                                     
        try:
            response2 = model_name.generate_content(prompt)
            context['bot_analysis'] = response2.text          
        except Exception as e:
            context['bot_analysis'] = "No analysis available"

        return context  
"""
class BaseStreamBlock(StreamBlock):
    imagetext_block = ImageBlock(
            icon="image",
            group="Options"
    ),
    chart_block = BlockChart(
            icon="openquote",
            group="Options"
    ),
"""
