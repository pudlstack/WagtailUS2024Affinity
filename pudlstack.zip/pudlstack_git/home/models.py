from django.db import models

from wagtail.models import Page
from wagtail.fields import RichTextField, StreamField
from wagtail.admin.panels import FieldPanel
from .blocks import TitleAndTextBlock, ImageBlock, ChartsBlock, UipathBlock


class HomePage(Page):
    body = StreamField(
         [
             ("title_and_text",TitleAndTextBlock()),
             ("image_and_caption",ImageBlock()),
             ("chart",ChartsBlock()),
             ("uipath",UipathBlock()), 
         ], null=True, blank=True, use_json_field=True
    )

    content_panels = Page.content_panels + [
        FieldPanel('body'),
    ]
